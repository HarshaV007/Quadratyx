from django.db import models
class Hero(models.Model):
    string = models.CharField(max_length=60)
    phone_number = models.CharField(max_length=60)
    def __str__(self):
        return self.phone_number

# Create your models here.
